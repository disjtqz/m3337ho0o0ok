#pragma once
	enum {
		_heapflag_no_serialize = 1,
	};