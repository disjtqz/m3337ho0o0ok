#pragma once

void install_error_handling_hooks();