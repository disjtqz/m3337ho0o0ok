#pragma once


void mh_install_security_cookie_regval_hook();