#pragma once


const char* get_clipboard_data();
void set_clipboard_data(const char* dat);