#pragma once

void install_memmanip_cmds();